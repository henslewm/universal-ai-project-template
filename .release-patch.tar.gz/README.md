# Universal AI Project Template

A repository-first operating system for complex, ongoing, high-stakes, source-heavy, or multi-session work across **ChatGPT, Codex, Claude, Claude Code, GitHub Copilot, and GitHub**.

The repository is the durable source of truth. Each AI surface gets a small native entrypoint that loads the same charter, state, decisions, sources, risks, and handoff record. Chats perform work; the repository preserves continuity.

## Fastest start

### No local installation - any modern browser, including iPhone and iPad

1. Select **Use this template** on GitHub and create a new repository. Use **Private** for personal, legal, regulated, proprietary, or identifying material.
2. Open `prompts/BOOTSTRAP_NEW_PROJECT.md` in the new repository and paste it into ChatGPT or Claude.
3. Connect that AI Project to the new GitHub repository.
4. Answer the compact intake. A write-capable client can update the repository; otherwise it should return exact commit-ready files or patches.
5. Open the repository in GitHub Codespaces only when a terminal is needed.

This route requires no locally installed Python, Git, or GitHub CLI. iOS and iPadOS use the browser/AI-Project or Codespaces route because they do not run the repository's local scripts directly.

### Windows 10/11

From PowerShell at the repository root:

```powershell
powershell -ExecutionPolicy Bypass -File .\bootstrap.ps1
```

The launcher finds Python 3.10+ and explains how to install it when missing. No third-party Python packages are required.

### macOS or Linux

From Terminal at the repository root:

```bash
./bootstrap.sh
```

The launcher finds Python 3.10+ and prints platform-specific installation guidance when missing. No third-party Python packages are required.

See [`QUICK_START.md`](QUICK_START.md) for route selection, retrofit commands, validation, and client setup.

## What this template creates

- A tailored project charter, current state, open-loop register, decision log, facts/assumptions ledger, source index, risk register, connector plan, skill plan, and handoff.
- Native entrypoints for Codex (`AGENTS.md`), Claude Code (`CLAUDE.md`), ChatGPT Projects, Claude Projects, and GitHub Copilot.
- A reusable `complex-project-bootstrapper` skill.
- Validation and cross-platform tests before handoff or release.
- Safe new-project, in-place template, and existing-repository retrofit modes.

## Local commands

### Tailor a repository created with GitHub **Use this template**

```bash
python scripts/bootstrap_project.py --interactive --destination .
```

The command refuses a dirty Git working tree unless `--allow-dirty` is explicitly supplied.

### Preserve the base template and create a sibling project

```bash
python scripts/bootstrap_project.py --interactive --destination ../my-project
```

### Retrofit an existing repository

Run this from the template repository and point it to the existing project:

```bash
python scripts/bootstrap_project.py --interactive --destination ../existing-project --retrofit
```

Retrofit mode copies only missing template files and preserves every file that already existed. Review the resulting diff before committing.

### Validate

```bash
python scripts/validate_project.py
python -m unittest discover -s tests -p "test_*.py"
```

## Native entrypoints

| Surface | Native entrypoint | Durable context |
|---|---|---|
| Codex | `AGENTS.md` | Universal rules, platform rules, charter, state, decisions, sources, risks, handoff |
| Claude Code | `CLAUDE.md` | Imports universal and Claude Code masters plus active state |
| ChatGPT Project | `.chatgpt/PROJECT_INSTRUCTIONS.md` | Compact active files plus current GitHub repository state |
| Claude Project | `.claude-web/PROJECT_INSTRUCTIONS.md` | GitHub integration plus active project knowledge |
| GitHub Copilot | `.github/copilot-instructions.md` | Universal rules and project state |

## Operating rule

**GitHub holds durable state; chats perform work.** A chat is not the project record unless material decisions, sources, current state, risks, and next actions are written back to the repository.

## Security default

Use a private repository for sensitive projects. Keep passwords, tokens, private keys, credential files, and unapproved restricted originals out of Git. Store authoritative originals in a controlled source system and track their location, authority, hash/version, and access scope in `SOURCE_INDEX.md`.

## Requirements

- **Browser-only path:** a GitHub account and an AI client; no local dependencies.
- **Local path:** Python 3.10 or newer. The scripts use only the Python standard library.
- **Optional:** Git for local history and GitHub CLI (`gh`) for command-line publication.

Current template version: **1.1.0**.
