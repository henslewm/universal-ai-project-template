#!/usr/bin/env sh
set -eu

OWNER="${1:-}"
REPO="${2:-$(basename "$PWD")}"
VISIBILITY="${3:-private}"

case "$VISIBILITY" in
    private|public|internal) ;;
    *) printf 'Visibility must be private, public, or internal.\n' >&2; exit 2 ;;
esac

command -v git >/dev/null 2>&1 || { printf 'Git is required.\n' >&2; exit 1; }
command -v gh >/dev/null 2>&1 || { printf 'GitHub CLI (gh) is required.\n' >&2; exit 1; }

PYTHON=""
for candidate in python3 python; do
    if command -v "$candidate" >/dev/null 2>&1 && "$candidate" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)' >/dev/null 2>&1; then
        PYTHON="$candidate"
        break
    fi
done
[ -n "$PYTHON" ] || { printf 'Python 3.10+ is required.\n' >&2; exit 1; }

gh auth status
"$PYTHON" scripts/validate_project.py
git status --short

if git remote get-url origin >/dev/null 2>&1; then
    git push -u origin HEAD
    exit 0
fi

if [ -n "$OWNER" ]; then
    TARGET="$OWNER/$REPO"
else
    TARGET="$REPO"
fi

gh repo create "$TARGET" "--$VISIBILITY" --source . --remote origin --push
